FactoryGirl.define do
  factory :post do
    content "This is a test for the post"
    user
  end
end
