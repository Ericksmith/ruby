FactoryGirl.define do
  factory :user do
    username "Testname"
  end
end
