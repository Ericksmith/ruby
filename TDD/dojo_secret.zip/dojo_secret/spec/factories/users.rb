FactoryGirl.define do
  factory :user do
    name "Bilbo"
    email "oscar@gmail.com"
    password "password"
  end
end
