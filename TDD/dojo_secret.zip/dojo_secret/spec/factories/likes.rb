FactoryGirl.define do
  factory :like do
    user
    secret
  end
end
